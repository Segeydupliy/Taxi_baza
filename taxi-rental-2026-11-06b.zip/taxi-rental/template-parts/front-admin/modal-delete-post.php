<?php
/**
 * Modal: Delete Blog Post confirmation.
 * Opened by JS when user clicks "Видалити" on a post row.
 */
?>
<div id="tb-fa-modal-delete-post" class="tb-fa-modal" hidden aria-modal="true" role="dialog"
     aria-labelledby="tb-fa-delete-post-heading">
	<div class="tb-fa-modal__backdrop" id="tb-fa-delete-post-backdrop"></div>
	<div class="tb-fa-modal__dialog tb-fa-modal__dialog--wide tb-fa-modal__dialog--centered">

		<div class="tb-fa-modal__icon-wrap" aria-hidden="true">
			<svg width="48" height="48" viewBox="0 0 48 48" fill="none">
				<path d="M25.425 33.425C25.8083 33.0417 26 32.5667 26 32C26 31.4333 25.8083 30.9583 25.425 30.575C25.0417 30.1917 24.5667 30 24 30C23.4333 30 22.9583 30.1917 22.575 30.575C22.1917 30.9583 22 31.4333 22 32C22 32.5667 22.1917 33.0417 22.575 33.425C22.9583 33.8083 23.4333 34 24 34C24.5667 34 25.0417 33.8083 25.425 33.425ZM22 26H26V14H22V26ZM24 44C21.2333 44 18.6333 43.475 16.2 42.425C13.7667 41.375 11.65 39.95 9.85 38.15C8.05 36.35 6.625 34.2333 5.575 31.8C4.525 29.3667 4 26.7667 4 24C4 21.2333 4.525 18.6333 5.575 16.2C6.625 13.7667 8.05 11.65 9.85 9.85C11.65 8.05 13.7667 6.625 16.2 5.575C18.6333 4.525 21.2333 4 24 4C26.7667 4 29.3667 4.525 31.8 5.575C34.2333 6.625 36.35 8.05 38.15 9.85C39.95 11.65 41.375 13.7667 42.425 16.2C43.475 18.6333 44 21.2333 44 24C44 26.7667 43.475 29.3667 42.425 31.8C41.375 34.2333 39.95 36.35 38.15 38.15C36.35 39.95 34.2333 41.375 31.8 42.425C29.3667 43.475 26.7667 44 24 44ZM24 40C28.4667 40 32.25 38.45 35.35 35.35C38.45 32.25 40 28.4667 40 24C40 19.5333 38.45 15.75 35.35 12.65C32.25 9.55 28.4667 8 24 8C19.5333 8 15.75 9.55 12.65 12.65C9.55 15.75 8 19.5333 8 24C8 28.4667 9.55 32.25 12.65 35.35C15.75 38.45 19.5333 40 24 40Z" fill="currentColor"/>
			</svg>
		</div>

		<h3 class="tb-fa-modal__title tb-fa-modal__title--center" id="tb-fa-delete-post-heading">
			<?php echo esc_html( tb_opt( 'tb_fa_mdp_title', 'Odstrániť článok?' ) ); ?>
		</h3>
		<p class="tb-fa-modal__desc tb-fa-modal__desc--center" id="tb-fa-delete-post-desc"
			data-tpl="<?php echo esc_attr( tb_opt( 'tb_fa_mdp_text', 'Naozaj chcete odstrániť článok „%s“?' ) ); ?>"></p>
		<div class="tb-fa-modal__footer tb-fa-modal__footer--spaced">
			<button type="button" class="tb-fa-btn tb-fa-btn--accent tb-fa-btn--flex" id="tb-fa-delete-post-cancel">
				<?php echo esc_html( tb_opt( 'tb_fa_mdp_cancel', 'Zrušiť' ) ); ?>
			</button>
			<button type="button" class="tb-fa-btn tb-fa-btn--dark tb-fa-btn--flex" id="tb-fa-delete-post-confirm">
				<?php echo esc_html( tb_opt( 'tb_fa_mdp_confirm', 'Odstrániť' ) ); ?>
			</button>
		</div>
	</div>
</div>
