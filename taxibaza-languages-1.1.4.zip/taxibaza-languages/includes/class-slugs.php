<?php
/**
 * Listing addresses must be unique inside each language folder.
 *
 * A machine translation gets the original's address (/uk/avto/<slug>/), but
 * when another listing of that language already has it (e.g. a hand-made
 * translation of a similar car), WordPress opened the older one and the new
 * listing could not be reached. Now the translation gets "-2", "-3"… in that
 * case, and the addresses that already collided are repaired once.
 *
 * @package TaxiBaza\Languages
 */

namespace TaxiBaza\Languages;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Slugs {

	public const DONE = 'tbl_slugs_fixed_1';

	/** @var callable|null Test hook: fn( string $slug, string $lang, int $except ): bool — is the address taken? */
	public static $taken = null;

	/** @var callable|null Test hook: fn(): array<int,array{id:int,lang:string,slug:string}> published listings. */
	public static $listings = null;

	public static function init(): void {
		add_action( 'admin_init', [ self::class, 'repair_once' ] );
	}

	public static function is_taken( string $slug, string $lang, int $except ): bool {
		if ( self::$taken ) {
			return (bool) call_user_func( self::$taken, $slug, $lang, $except );
		}
		global $wpdb;
		return (bool) $wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->prepare(
				"SELECT p.ID FROM {$wpdb->posts} p
				 INNER JOIN {$wpdb->prefix}icl_translations t ON t.element_id = p.ID AND t.element_type = %s
				 WHERE p.post_type = 'car_listing' AND p.post_status NOT IN ('trash','auto-draft')
				   AND p.post_name = %s AND t.language_code = %s AND p.ID <> %d LIMIT 1",
				Groups::TYPE,
				$slug,
				$lang,
				$except
			)
		);
	}

	/** The address itself if it is free in that language, otherwise "<slug>-2", "-3"… */
	public static function unique( string $slug, string $lang, int $except ): string {
		$slug = '' !== $slug ? $slug : 'auto';
		if ( ! self::is_taken( $slug, $lang, $except ) ) {
			return $slug;
		}
		$base = $slug; // Not stripping "-2021": the year is part of most addresses.
		for ( $n = 2; $n < 200; $n++ ) {
			if ( ! self::is_taken( $base . '-' . $n, $lang, $except ) ) {
				return $base . '-' . $n;
			}
		}
		return $base . '-' . $except;
	}

	/** @return array<int,array{id:int,lang:string,slug:string}> */
	private static function listings(): array {
		if ( self::$listings ) {
			return (array) call_user_func( self::$listings );
		}
		global $wpdb;
		$rows = $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->prepare(
				"SELECT p.ID AS id, t.language_code AS lang, p.post_name AS slug FROM {$wpdb->posts} p
				 INNER JOIN {$wpdb->prefix}icl_translations t ON t.element_id = p.ID AND t.element_type = %s
				 WHERE p.post_type = 'car_listing' AND p.post_status NOT IN ('trash','auto-draft') AND p.post_name <> ''
				 ORDER BY p.ID",
				Groups::TYPE
			),
			ARRAY_A
		);
		return array_map( static fn( $r ) => [ 'id' => (int) $r['id'], 'lang' => (string) $r['lang'], 'slug' => (string) $r['slug'] ], (array) $rows );
	}

	/**
	 * Listings sharing an address in one language: the oldest keeps it (that is
	 * the one WordPress has been opening), the others get a free one.
	 *
	 * @return array<int,string> Renamed listing ID => new address.
	 */
	public static function plan(): array {
		$seen = [];
		$out  = [];
		foreach ( self::listings() as $r ) {
			$key = $r['lang'] . '|' . $r['slug'];
			if ( isset( $seen[ $key ] ) ) {
				$out[ $r['id'] ] = '';
			} else {
				$seen[ $key ] = $r['id'];
			}
		}
		return $out;
	}

	/** @return array<int,string> */
	public static function repair(): array {
		$done = [];
		$rows = [];
		foreach ( self::listings() as $r ) {
			$rows[ $r['id'] ] = $r;
		}
		foreach ( array_keys( self::plan() ) as $id ) {
			$r    = $rows[ $id ];
			$slug = self::unique( $r['slug'], $r['lang'], $id );
			if ( $slug !== $r['slug'] ) {
				Auto_Translate::quietly(
					static function () use ( $id, $slug ): void {
						wp_update_post( [ 'ID' => $id, 'post_name' => $slug ] );
					}
				);
				$done[ $id ] = $slug;
			}
		}
		return $done;
	}

	public static function repair_once(): void {
		if ( get_option( self::DONE ) || ! Groups::wpml() || ! current_user_can( 'manage_options' ) ) {
			return;
		}
		update_option( self::DONE, [ 'at' => time(), 'renamed' => self::repair() ], false );
	}
}
