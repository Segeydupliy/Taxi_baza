<?php
/**
 * Pages that must never come from a page cache (WP Rocket or any other):
 * login / registration, the user cabinet and "Add listing", the admin panel.
 * They carry fresh nonces, the logged-in state and the language switcher of
 * the current user. Detected by page template, so it works in every language
 * and keeps working if a slug is renamed. Sets DONOTCACHEPAGE (honoured by
 * WP Rocket, W3TC, LiteSpeed…) and no-cache headers.
 *
 * @package TaxiBaza\Speed
 */

namespace TaxiBaza\Speed;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class No_Cache {

	public const TEMPLATES = [ 'page-login.php', 'page-dashboard.php', 'page-add-listing.php', 'page-front-admin.php' ];

	public static function init(): void {
		add_action( 'template_redirect', [ self::class, 'check' ], 0 );
	}

	public static function is_private_page(): bool {
		if ( ! is_page() ) {
			return false;
		}
		$template = (string) get_page_template_slug( (int) get_queried_object_id() );
		return in_array( $template, self::TEMPLATES, true );
	}

	public static function check(): void {
		if ( ! self::is_private_page() ) {
			return;
		}
		if ( ! defined( 'DONOTCACHEPAGE' ) ) {
			define( 'DONOTCACHEPAGE', true );
		}
		if ( ! headers_sent() ) {
			nocache_headers();
		}
	}
}
