<?php
/**
 * Yoast SEO titles and descriptions in the visitor's language.
 *
 * The templates (catalogue, city / platform / category pages, search, 404)
 * are translated in WPML → String Translation, domain
 * "admin_texts_wpseo_titles". Yoast reads its settings once, before WPML
 * knows the language, so it always used the Slovak template: "Archívy
 * Братислава" on /uk/mesto/bratislava/. Here the translated template is
 * taken for the current language and filled in by Yoast itself.
 * Slovak pages and pages with their own SEO title are not touched.
 *
 * @package TaxiBaza\Languages
 */

namespace TaxiBaza\Languages;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Yoast_I18n {

	public const CTX = 'admin_texts_wpseo_titles';

	public static function init(): void {
		add_filter( 'wpseo_title', [ self::class, 'title' ], 20 );
		add_filter( 'wpseo_opengraph_title', [ self::class, 'social_title' ], 20 );
		add_filter( 'wpseo_twitter_title', [ self::class, 'social_title' ], 20 );
		add_filter( 'wpseo_metadesc', [ self::class, 'desc' ], 20 );
		add_filter( 'wpseo_opengraph_desc', [ self::class, 'desc' ], 20 );
		add_filter( 'wpseo_twitter_description', [ self::class, 'desc' ], 20 );
		add_action( 'wp_footer', [ self::class, 'debug' ], 999 );
	}

	/** For admins with ?tbl_seo=1: what was found for this page (HTML comment). */
	public static function debug(): void {
		if ( ! isset( $_GET['tbl_seo'] ) || ! current_user_can( 'manage_options' ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			return;
		}
		$p    = self::page();
		$name = $p ? 'title-' . $p[0] : '';
		$info = [
			'lang' => self::lang(),
			'page' => $p ? $p[0] : null,
			'src'  => $p && class_exists( '\WPSEO_Options' ) ? \WPSEO_Options::get( $name, '' ) : null,
			'tr'   => $p && self::lang() ? self::translation( $name, self::lang() ) : null,
			'out'  => $p ? self::render( $name, $p[1] ) : null,
		];
		echo "\n<!-- tbl_seo " . esc_html( (string) wp_json_encode( $info, JSON_UNESCAPED_UNICODE ) ) . " -->\n";
	}

	/** Current language when it is not the default one, else ''. */
	public static function lang(): string {
		$cur = (string) apply_filters( 'wpml_current_language', null );
		$def = (string) apply_filters( 'wpml_default_language', null );
		return ( '' !== $cur && '' !== $def && $cur !== $def ) ? $cur : '';
	}

	/**
	 * Which Yoast template this page uses: [ suffix, object for the variables ].
	 *
	 * @return array{0:string,1:mixed}|null
	 */
	public static function page(): ?array {
		if ( is_post_type_archive() ) {
			// The queried object, not the query var: the catalogue query is widened
			// to all languages, which can change its post_type var.
			$obj = get_queried_object();
			$pt  = $obj instanceof \WP_Post_Type ? $obj->name : get_query_var( 'post_type' );
			$pt  = is_array( $pt ) ? (string) reset( $pt ) : (string) $pt;
			if ( 'any' === $pt || '' === $pt ) {
				$pt = 'car_listing';
			}
			return '' !== $pt ? [ 'ptarchive-' . $pt, (object) [ 'post_type' => $pt ] ] : null;
		}
		if ( is_category() || is_tag() || is_tax() ) {
			$term = get_queried_object();
			if ( ! $term instanceof \WP_Term ) {
				return null;
			}
			return [ 'tax-' . $term->taxonomy, $term ];
		}
		if ( is_search() ) {
			return [ 'search-wpseo', null ];
		}
		if ( is_404() ) {
			return [ '404-wpseo', null ];
		}
		return null;
	}

	/** Has the term its own SEO title / description set in Yoast? */
	private static function own( $obj, string $field ): bool {
		if ( ! $obj instanceof \WP_Term || ! class_exists( '\WPSEO_Taxonomy_Meta' ) ) {
			return false;
		}
		return '' !== (string) \WPSEO_Taxonomy_Meta::get_term_meta( $obj, $obj->taxonomy, $field );
	}

	/** @var callable|null Test hook: fn( string $name, string $lang ): string. */
	public static $lookup = null;

	/** @var array<string,string> */
	private static array $cache = [];

	/**
	 * The translation saved in String Translation. Read directly: going through
	 * WPML with Yoast's value re-registers the string whenever the two differ
	 * by a character (e.g. "–" stored as an entity) and returns Slovak.
	 */
	public static function translation( string $name, string $lang ): string {
		if ( self::$lookup ) {
			return (string) call_user_func( self::$lookup, $name, $lang );
		}
		$key = $lang . '|' . $name;
		if ( ! isset( self::$cache[ $key ] ) ) {
			global $wpdb;
			self::$cache[ $key ] = (string) $wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
				$wpdb->prepare(
					"SELECT t.value FROM {$wpdb->prefix}icl_strings s
					 INNER JOIN {$wpdb->prefix}icl_string_translations t ON t.string_id = s.id
					 WHERE s.context = %s AND s.name = %s AND t.language = %s AND t.value <> '' AND t.status IN (3, 10)
					 ORDER BY t.status DESC LIMIT 1",
					self::CTX,
					'[wpseo_titles]' . $name,
					$lang
				)
			);
		}
		return self::$cache[ $key ];
	}

	/** Translated, filled-in template, or null when there is no translation. */
	public static function render( string $name, $obj ): ?string {
		$lang = self::lang();
		if ( '' === $lang || ! class_exists( '\WPSEO_Options' ) ) {
			return null;
		}
		$src = (string) \WPSEO_Options::get( $name, '' );
		if ( '' === trim( $src ) ) {
			return null;
		}
		$tr = self::translation( $name, $lang );
		if ( '' === trim( $tr ) ) {
			return null;
		}
		$out = function_exists( 'wpseo_replace_vars' ) ? wpseo_replace_vars( $tr, $obj ?? [] ) : $tr;
		return trim( (string) preg_replace( '/\s+/', ' ', (string) $out ) );
	}

	public static function title( $title ) {
		$p = self::page();
		if ( ! $p || self::own( $p[1], 'title' ) ) {
			return $title;
		}
		return self::render( 'title-' . $p[0], $p[1] ) ?? $title;
	}

	public static function social_title( $title ) {
		$p = self::page();
		if ( ! $p || self::own( $p[1], 'title' ) || self::own( $p[1], 'opengraph-title' ) ) {
			return $title;
		}
		return self::render( 'social-title-' . $p[0], $p[1] ) ?? self::render( 'title-' . $p[0], $p[1] ) ?? $title;
	}

	public static function desc( $desc ) {
		$p = self::page();
		if ( ! $p || self::own( $p[1], 'desc' ) ) {
			return $desc;
		}
		return self::render( 'metadesc-' . $p[0], $p[1] ) ?? $desc;
	}
}
