<?php
/**
 * Yoast SEO titles and descriptions in the visitor's language.
 *
 * The templates (catalogue, city / platform / category pages, search, 404)
 * are translated in WPML → String Translation, domain
 * "admin_texts_wpseo_titles". Yoast reads its settings once, before WPML
 * knows the language, so it always used the Slovak template: "Archívy
 * Братислава" on /uk/mesto/bratislava/. Here the translated template is
 * taken for the current language and filled in by Yoast itself.
 * Slovak pages and pages with their own SEO title are not touched.
 *
 * @package TaxiBaza\Languages
 */

namespace TaxiBaza\Languages;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Yoast_I18n {

	public const CTX = 'admin_texts_wpseo_titles';

	public static function init(): void {
		add_filter( 'wpseo_title', [ self::class, 'title' ], 20 );
		add_filter( 'wpseo_opengraph_title', [ self::class, 'social_title' ], 20 );
		add_filter( 'wpseo_twitter_title', [ self::class, 'social_title' ], 20 );
		add_filter( 'wpseo_metadesc', [ self::class, 'desc' ], 20 );
		add_filter( 'wpseo_opengraph_desc', [ self::class, 'desc' ], 20 );
		add_filter( 'wpseo_twitter_description', [ self::class, 'desc' ], 20 );
	}

	/** Current language when it is not the default one, else ''. */
	public static function lang(): string {
		$cur = (string) apply_filters( 'wpml_current_language', null );
		$def = (string) apply_filters( 'wpml_default_language', null );
		return ( '' !== $cur && '' !== $def && $cur !== $def ) ? $cur : '';
	}

	/**
	 * Which Yoast template this page uses: [ suffix, object for the variables ].
	 *
	 * @return array{0:string,1:mixed}|null
	 */
	public static function page(): ?array {
		if ( is_post_type_archive() ) {
			$pt = get_query_var( 'post_type' );
			$pt = is_array( $pt ) ? (string) reset( $pt ) : (string) $pt;
			return '' !== $pt ? [ 'ptarchive-' . $pt, (object) [ 'post_type' => $pt ] ] : null;
		}
		if ( is_category() || is_tag() || is_tax() ) {
			$term = get_queried_object();
			if ( ! $term instanceof \WP_Term ) {
				return null;
			}
			return [ 'tax-' . $term->taxonomy, $term ];
		}
		if ( is_search() ) {
			return [ 'search-wpseo', null ];
		}
		if ( is_404() ) {
			return [ '404-wpseo', null ];
		}
		return null;
	}

	/** Has the term its own SEO title / description set in Yoast? */
	private static function own( $obj, string $field ): bool {
		if ( ! $obj instanceof \WP_Term || ! class_exists( '\WPSEO_Taxonomy_Meta' ) ) {
			return false;
		}
		return '' !== (string) \WPSEO_Taxonomy_Meta::get_term_meta( $obj, $obj->taxonomy, $field );
	}

	/** Translated, filled-in template, or null when there is no translation. */
	public static function render( string $name, $obj ): ?string {
		$lang = self::lang();
		if ( '' === $lang || ! class_exists( '\WPSEO_Options' ) ) {
			return null;
		}
		$src = (string) \WPSEO_Options::get( $name, '' );
		if ( '' === trim( $src ) ) {
			return null;
		}
		$tr = (string) apply_filters( 'wpml_translate_single_string', $src, self::CTX, '[wpseo_titles]' . $name, $lang );
		if ( '' === trim( $tr ) || $tr === $src ) {
			return null;
		}
		$out = function_exists( 'wpseo_replace_vars' ) ? wpseo_replace_vars( $tr, $obj ?? [] ) : $tr;
		return trim( (string) preg_replace( '/\s+/', ' ', (string) $out ) );
	}

	public static function title( $title ) {
		$p = self::page();
		if ( ! $p || self::own( $p[1], 'title' ) ) {
			return $title;
		}
		return self::render( 'title-' . $p[0], $p[1] ) ?? $title;
	}

	public static function social_title( $title ) {
		$p = self::page();
		if ( ! $p || self::own( $p[1], 'title' ) || self::own( $p[1], 'opengraph-title' ) ) {
			return $title;
		}
		return self::render( 'social-title-' . $p[0], $p[1] ) ?? self::render( 'title-' . $p[0], $p[1] ) ?? $title;
	}

	public static function desc( $desc ) {
		$p = self::page();
		if ( ! $p || self::own( $p[1], 'desc' ) ) {
			return $desc;
		}
		return self::render( 'metadesc-' . $p[0], $p[1] ) ?? $desc;
	}
}
